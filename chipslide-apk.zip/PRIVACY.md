# Política de privacidad – Chipslide
Chipslide no recopila, almacena ni comparte datos personales. El progreso (nivel, puntuación) se guarda solo en el dispositivo. La app no contiene anuncios ni analíticas y no requiere conexión a Internet.
