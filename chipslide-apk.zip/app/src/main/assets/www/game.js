/* CHIPSLIDE - original LCD-style puzzle. Procedural levels (always solvable), WebAudio synth, haptics, daily seed. */
(() => {
'use strict';
const W = 144, H = 216;
const BG = '#a9b894', INK = '#1d261b';
const cv = document.getElementById('lcd'), ctx = cv.getContext('2d');
const buf = document.createElement('canvas'); buf.width = W; buf.height = H;
const b = buf.getContext('2d');
const prev = document.createElement('canvas'); prev.width = W; prev.height = H;
const pc = prev.getContext('2d');

/* ---------- persistence ---------- */
const KEY = 'chipslide.v1';
let save = { level: 1, score: 0, stars: {}, daily: {}, muted: false };
try { Object.assign(save, JSON.parse(localStorage.getItem(KEY) || '{}')); } catch (e) {}
const persist = () => { try { localStorage.setItem(KEY, JSON.stringify(save)); } catch (e) {} };

/* ---------- audio (synth, no asset files) ---------- */
let ac = null;
function audio() {
  if (!ac) { try { ac = new (window.AudioContext || window.webkitAudioContext)(); } catch (e) {} }
  if (ac && ac.state === 'suspended') ac.resume();
  return ac;
}
function beep(f, d, type = 'square', vol = 0.05, f2 = 0, delay = 0) {
  if (save.muted) return;
  const a = audio(); if (!a) return;
  const t = a.currentTime + delay, o = a.createOscillator(), g = a.createGain();
  o.type = type; o.frequency.setValueAtTime(f, t);
  if (f2) o.frequency.exponentialRampToValueAtTime(f2, t + d);
  g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.0001, t + d);
  o.connect(g); g.connect(a.destination); o.start(t); o.stop(t + d + 0.02);
}
const sfx = {
  slide: () => beep(380, 0.12, 'square', 0.05, 980),
  bump: () => { beep(120, 0.22, 'sawtooth', 0.07, 60); if (navigator.vibrate) navigator.vibrate(25); },
  hint: () => { beep(880, 0.05); beep(1175, 0.07, 'square', 0.05, 0, 0.07); },
  click: () => beep(660, 0.04),
  win: () => [523, 659, 784, 1047, 784, 1047].forEach((f, i) => beep(f, 0.12, 'square', 0.05, 0, i * 0.1)),
  lose: () => [392, 330, 262, 196].forEach((f, i) => beep(f, 0.2, 'square', 0.05, 0, i * 0.16)),
};

/* ---------- pixel font 3x5 + seven segment ---------- */
const F = {
  A: [2,5,7,5,5], B: [6,5,6,5,6], C: [3,4,4,4,3], D: [6,5,5,5,6], E: [7,4,6,4,7], F: [7,4,6,4,4],
  G: [3,4,5,5,3], H: [5,5,7,5,5], I: [7,2,2,2,7], J: [1,1,1,5,2], K: [5,5,6,5,5], L: [4,4,4,4,7],
  M: [5,7,7,5,5], N: [7,5,5,5,5], O: [2,5,5,5,2], P: [6,5,6,4,4], Q: [2,5,5,7,3], R: [6,5,6,5,5],
  S: [3,4,2,1,6], T: [7,2,2,2,2], U: [5,5,5,5,7], V: [5,5,5,5,2], W: [5,5,7,7,5], X: [5,5,2,5,5],
  Y: [5,5,2,2,2], Z: [7,1,2,4,7], 0: [7,5,5,5,7], 1: [2,6,2,2,7], 2: [6,1,2,4,7], 3: [6,1,2,1,6],
  4: [5,5,7,1,1], 5: [7,4,6,1,6], 6: [3,4,7,5,7], 7: [7,1,2,2,2], 8: [7,5,7,5,7], 9: [7,5,7,1,6],
  '.': [0,0,0,0,2], ':': [0,2,0,2,0], '!': [2,2,2,0,2], '-': [0,0,7,0,0], '/': [1,1,2,4,4],
  '?': [6,1,2,0,2], '+': [0,2,7,2,0], ' ': [0,0,0,0,0], 'X_': [0,0,0,0,0],
};
function text(s, x, y, sc = 1, a = 1) {
  b.globalAlpha = a; b.fillStyle = INK;
  s = String(s).toUpperCase();
  for (const ch of s) {
    const g = F[ch] || F['?'];
    for (let r = 0; r < 5; r++) for (let c = 0; c < 3; c++) if (g[r] & (4 >> c)) b.fillRect(x + c * sc, y + r * sc, sc, sc);
    x += 4 * sc;
  }
  b.globalAlpha = 1;
}
const tw = (s, sc = 1) => String(s).length * 4 * sc - sc;
const ctext = (s, y, sc = 1, a = 1) => text(s, Math.round((W - tw(s, sc)) / 2), y, sc, a);

const SEG = [0x3f, 0x06, 0x5b, 0x4f, 0x66, 0x6d, 0x7d, 0x07, 0x7f, 0x6f];
function digit(d, x, y) {
  const m = SEG[d], r = [[1,0,4,1],[5,1,1,4],[5,6,1,4],[1,10,4,1],[0,6,1,4],[0,1,1,4],[1,5,4,1]];
  for (let i = 0; i < 7; i++) { b.globalAlpha = (m >> i) & 1 ? 1 : 0.07; b.fillRect(x + r[i][0], y + r[i][1], r[i][2], r[i][3]); }
  b.globalAlpha = 1;
}
function number(n, len, x, y) {
  const s = String(Math.max(0, n | 0)).padStart(len, '0').slice(-len);
  b.fillStyle = INK;
  for (let i = 0; i < len; i++) digit(+s[i], x + i * 8, y);
}
function star(x, y, on) {
  const rows = ['00100', '01110', '11111', '01110', '10101'];
  b.fillStyle = INK; b.globalAlpha = on ? 1 : 0.18;
  rows.forEach((r, j) => [...r].forEach((c, i) => { if (c === '1') b.fillRect(x + i, y + j, 1, 1); }));
  b.globalAlpha = 1;
}

/* ---------- level generation (reverse-construction => always solvable) ---------- */
function rng(seed) {
  let a = seed >>> 0;
  return () => { a = (a + 0x6D2B79F5) >>> 0; let t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
}
const DIRS = [[1, 0], [-1, 0], [0, 1], [0, -1]];
function params(level, daily) {
  if (daily) return { cols: 7, rows: 10, maxLen: 3, fill: 0.62 };
  return {
    cols: Math.min(9, 5 + Math.floor((level - 1) / 2)),
    rows: Math.min(12, 6 + Math.floor(level * 0.7)),
    maxLen: level < 3 ? 2 : 3,
    fill: 0.45 + Math.min(0.25, level * 0.015),
  };
}
function generate(p, seed) {
  const r = rng(seed), { cols, rows, maxLen, fill } = p;
  const occ = new Int16Array(cols * rows).fill(-1), chips = [];
  let used = 0, fails = 0;
  const target = Math.floor(cols * rows * fill);
  while (used < target && fails < cols * rows * 40) {
    const d = DIRS[(r() * 4) | 0], len = 1 + ((r() * maxLen) | 0);
    const hx = (r() * cols) | 0, hy = (r() * rows) | 0;
    const cells = []; let ok = true;
    for (let i = len - 1; i >= 0; i--) {
      const x = hx - d[0] * i, y = hy - d[1] * i;
      if (x < 0 || y < 0 || x >= cols || y >= rows || occ[y * cols + x] >= 0) { ok = false; break; }
      cells.push({ x, y });
    }
    if (ok) {
      let x = hx + d[0], y = hy + d[1];
      while (x >= 0 && y >= 0 && x < cols && y < rows) { if (occ[y * cols + x] >= 0) { ok = false; break; } x += d[0]; y += d[1]; }
    }
    if (!ok) { fails++; continue; }
    const id = chips.length;
    cells.forEach(c => (occ[c.y * cols + c.x] = id));
    chips.push({ id, cells, dx: d[0], dy: d[1], alive: true, off: 0, v: 0, flash: 0, bump: 0 });
    used += len;
  }
  return { cols, rows, occ, chips };
}
const dailySeed = () => { const d = new Date(); return d.getFullYear() * 10000 + (d.getMonth() + 1) * 100 + d.getDate(); };
const dailyKey = () => String(dailySeed());

/* ---------- game state ---------- */
let mode = 'title', G = null, T = 0, flash = 0, msg = '', msgT = 0, cell = 14, ox = 0, oy = 34;

function layout() {
  const aw = W - 4, ah = H - 38 - 2;
  cell = Math.floor(Math.min(aw / G.cols, ah / G.rows));
  ox = Math.floor((W - cell * G.cols) / 2);
  oy = 34 + Math.floor((ah - cell * G.rows) / 2);
}
function startLevel(level, daily = false) {
  const p = params(level, daily), seed = daily ? dailySeed() : level * 7919 + 13;
  G = generate(p, seed);
  Object.assign(G, { level, daily, lives: 3, hints: 3, combo: 0, hintChip: -1, hintT: 0, sliding: null, scoreStart: save.score, left: G.chips.length, gained: 0 });
  layout(); mode = 'play';
}
function blockerOf(c) {
  const hd = c.cells[c.cells.length - 1];
  let x = hd.x + c.dx, y = hd.y + c.dy;
  while (x >= 0 && y >= 0 && x < G.cols && y < G.rows) { const id = G.occ[y * G.cols + x]; if (id >= 0) return id; x += c.dx; y += c.dy; }
  return -1;
}
function tap(px, py) {
  if (G.sliding) return;
  const cx = Math.floor((px - ox) / cell), cy = Math.floor((py - oy) / cell);
  if (cx < 0 || cy < 0 || cx >= G.cols || cy >= G.rows) return;
  const id = G.occ[cy * G.cols + cx]; if (id < 0) return;
  const c = G.chips[id], bl = blockerOf(c);
  G.hintChip = -1;
  if (bl < 0) {
    c.cells.forEach(q => (G.occ[q.y * G.cols + q.x] = -1));
    c.v = 6; c.off = 0; G.sliding = c; G.combo++;
    const add = 10 * c.cells.length * Math.min(G.combo, 5);
    save.score += add; G.gained += add; sfx.slide();
  } else {
    c.bump = 0.3; G.chips[bl].flash = 0.6; G.lives--; G.combo = 0; flash = 0.12; sfx.bump();
    if (G.lives <= 0) { mode = 'lose'; sfx.lose(); save.score = G.scoreStart; persist(); }
  }
}
function finishSlide() {
  const c = G.sliding; c.alive = false; G.sliding = null; G.left--;
  if (G.left <= 0) {
    const stars = Math.max(1, G.lives);
    if (G.daily) { save.daily[dailyKey()] = Math.max(stars, save.daily[dailyKey()] || 0); }
    else { save.stars[G.level] = Math.max(stars, save.stars[G.level] || 0); save.level = Math.max(save.level, G.level + 1); }
    G.stars = stars; mode = 'win'; sfx.win(); persist();
  }
}
function hint() {
  if (mode !== 'play' || G.hints <= 0 || G.sliding) return;
  const ok = G.chips.filter(c => c.alive && G.occ[c.cells[0].y * G.cols + c.cells[0].x] === c.id && blockerOf(c) < 0);
  if (!ok.length) return;
  G.hints--; G.hintChip = ok[(Math.random() * ok.length) | 0].id; G.hintT = 2.2; sfx.hint();
}
function reset() { if (G && mode !== 'title') { save.score = G.scoreStart; startLevel(G.level, G.daily); sfx.click(); } }

/* ---------- drawing ---------- */
function drawArrow(cx, cy, dx, dy, a) {
  b.fillStyle = BG;
  const P = (t, u) => {
    const x = dx ? cx + dx * t : cx + u, y = dy ? cy + dy * t : cy + u;
    b.fillRect(Math.round(x), Math.round(y), 1, 1);
  };
  for (let t = -a; t <= a; t++) { const hw = Math.floor((a - t) / 2); for (let u = -hw; u <= hw; u++) P(t, u); }
  for (let t = -a - 3; t < -a; t++) P(t, 0);
}
function drawChip(c, blink) {
  const xs = c.cells.map(q => q.x), ys = c.cells.map(q => q.y);
  let sh = 0; if (c.bump > 0) sh = Math.sin(c.bump * 60) * 1.5;
  const offx = c.off * c.dx * cell + c.dx * sh, offy = c.off * c.dy * cell + c.dy * sh;
  const x = ox + Math.min(...xs) * cell + 2 + Math.round(offx), y = oy + Math.min(...ys) * cell + 2 + Math.round(offy);
  const w = (Math.max(...xs) - Math.min(...xs) + 1) * cell - 4, h = (Math.max(...ys) - Math.min(...ys) + 1) * cell - 4;
  const hd = c.cells[c.cells.length - 1];
  const cx = ox + hd.x * cell + (cell >> 1) + Math.round(offx), cy = oy + hd.y * cell + (cell >> 1) + Math.round(offy);
  b.fillStyle = INK;
  if (blink) { b.fillRect(x, y, w, 1); b.fillRect(x, y + h - 1, w, 1); b.fillRect(x, y, 1, h); b.fillRect(x + w - 1, y, 1, h); return; }
  b.fillRect(x, y, w, h);
  // bevel highlight (LCD depth)
  b.fillStyle = BG; b.globalAlpha = 0.25; b.fillRect(x + 1, y + 1, w - 2, 1); b.globalAlpha = 1;
  drawArrow(cx, cy, c.dx, c.dy, Math.max(2, Math.floor(cell * 0.28)));
}
function header() {
  text('LV', 3, 4, 1, 0.7); number(G.daily ? 0 : G.level, 2, 12, 3);
  text('SC', 52, 4, 1, 0.7); number(save.score, 5, 62, 3);
  b.fillStyle = INK;
  for (let i = 0; i < 3; i++) { b.globalAlpha = i < G.lives ? 1 : 0.12; b.fillRect(3 + i * 8, 21, 6, 7); }
  b.globalAlpha = 1; b.fillRect(26, 23, 1, 3);
  text('HINT ' + G.hints, 80, 22, 1, 0.9);
  if (G.combo > 1) text('X' + Math.min(G.combo, 5), 50, 22);
  if (G.daily) text('DAILY', 104, 4, 1, 0.9);
  b.globalAlpha = 0.5; b.fillRect(2, 32, W - 4, 1); b.globalAlpha = 1;
}
function panel(h) {
  const w = 112, x = (W - w) >> 1, y = ((H - h) >> 1) + 8;
  b.fillStyle = BG; b.fillRect(x, y, w, h); b.fillStyle = INK;
  b.fillRect(x, y, w, 2); b.fillRect(x, y + h - 2, w, 2); b.fillRect(x, y, 2, h); b.fillRect(x + w - 2, y, 2, h);
  return y;
}
function drawBoard() {
  b.save(); b.beginPath(); b.rect(ox, oy, cell * G.cols, cell * G.rows); b.clip();
  b.fillStyle = INK; b.globalAlpha = 0.3;
  for (let y = 0; y < G.rows; y++) for (let x = 0; x < G.cols; x++) if (G.occ[y * G.cols + x] < 0) b.fillRect(ox + x * cell + (cell >> 1), oy + y * cell + (cell >> 1), 1, 1);
  b.globalAlpha = 1;
  for (const c of G.chips) {
    if (!c.alive && c !== G.sliding) continue;
    const blink = (c.id === G.hintChip && G.hintT > 0 && Math.floor(T * 8) % 2 === 0) || (c.flash > 0 && Math.floor(T * 16) % 2 === 0);
    drawChip(c, blink);
  }
  b.restore();
  b.fillStyle = INK; b.globalAlpha = 0.5;
  b.fillRect(ox - 1, oy - 1, cell * G.cols + 2, 1); b.fillRect(ox - 1, oy + cell * G.rows, cell * G.cols + 2, 1);
  b.fillRect(ox - 1, oy - 1, 1, cell * G.rows + 2); b.fillRect(ox + cell * G.cols, oy - 1, 1, cell * G.rows + 2);
  b.globalAlpha = 1;
}
function drawTitle() {
  ctext('CHIP', 18, 4); ctext('SLIDE', 42, 4);
  // demo chips sliding across
  b.save(); b.beginPath(); b.rect(8, 80, W - 16, 30); b.clip();
  for (let i = 0; i < 4; i++) {
    const len = 1 + (i % 3), x = ((T * 28 + i * 52) % (W + 60)) - 40, y = 84 + (i % 2) * 14;
    b.fillStyle = INK; b.fillRect(Math.round(x), y, len * 12 - 3, 10);
    b.fillStyle = BG; const hx = Math.round(x) + len * 12 - 9;
    for (let t = 0; t < 4; t++) for (let u = -(3 - t); u <= 3 - t; u++) b.fillRect(hx + t, y + 5 + u, 1, 1);
  }
  b.restore();
  const lv = save.level;
  ctext('LEVEL ' + String(lv).padStart(2, '0'), 122, 1, 0.9);
  if (Math.floor(T * 2) % 2 === 0) ctext('TAP TO PLAY', 140, 2);
  ctext('SCORE ' + String(save.score).padStart(5, '0'), 164, 1, 0.8);
  const ds = save.daily[dailyKey()];
  ctext(ds ? 'DAILY DONE' : 'DAILY: PRESS BTN', 178, 1, 0.8);
  ctext(save.muted ? 'SOUND OFF' : 'SOUND ON', 192, 1, 0.5);
}
function render() {
  b.clearRect(0, 0, W, H);
  if (mode === 'title') drawTitle();
  else {
    header(); drawBoard();
    if (mode === 'win') {
      const y = panel(64); ctext(G.daily ? 'DAILY CLEAR!' : 'LEVEL CLEAR!', y + 8, 1);
      for (let i = 0; i < 3; i++) star((W >> 1) - 20 + i * 14, y + 22, i < G.stars);
      ctext('+' + G.gained + ' PTS', y + 36, 1); if (Math.floor(T * 2) % 2 === 0) ctext('TAP', y + 50, 1);
    } else if (mode === 'lose') {
      const y = panel(52); ctext('BATTERY LOW', y + 8, 1); ctext('GAME OVER', y + 22, 1);
      if (Math.floor(T * 2) % 2 === 0) ctext('TAP TO RETRY', y + 38, 1);
    }
  }
  ctx.globalCompositeOperation = 'source-over';
  ctx.fillStyle = BG; ctx.fillRect(0, 0, W, H);
  ctx.globalAlpha = 0.3; ctx.drawImage(prev, 0, 0);          // LCD ghosting
  ctx.globalAlpha = 0.16; ctx.drawImage(buf, 1, 1);            // pixel shadow
  ctx.globalAlpha = 1; ctx.drawImage(buf, 0, 0);
  if (flash > 0) { ctx.globalAlpha = flash * 2; ctx.fillStyle = INK; ctx.fillRect(0, 0, W, H); ctx.globalAlpha = 1; }
  pc.clearRect(0, 0, W, H); pc.drawImage(cv, 0, 0);
}

/* ---------- loop ---------- */
let last = 0;
function frame(ts) {
  const dt = Math.min(0.05, (ts - last) / 1000 || 0.016); last = ts; T += dt;
  if (flash > 0) flash -= dt;
  if (G) {
    if (G.hintT > 0) { G.hintT -= dt; if (G.hintT <= 0) G.hintChip = -1; }
    for (const c of G.chips) { if (c.flash > 0) c.flash -= dt; if (c.bump > 0) c.bump -= dt; }
    if (G.sliding) {
      const c = G.sliding; c.v += 160 * dt; c.off += c.v * dt;
      if (c.off > Math.max(G.cols, G.rows) + 4) finishSlide();
    }
  }
  render(); requestAnimationFrame(frame);
}

/* ---------- input ---------- */
cv.addEventListener('pointerdown', e => {
  e.preventDefault(); audio();
  const r = cv.getBoundingClientRect(), x = (e.clientX - r.left) / r.width * W, y = (e.clientY - r.top) / r.height * H;
  if (mode === 'title') { startLevel(save.level); sfx.click(); }
  else if (mode === 'win') { if (G.daily) mode = 'title'; else startLevel(G.level + 1); sfx.click(); }
  else if (mode === 'lose') { startLevel(G.level, G.daily); sfx.click(); }
  else if (mode === 'play') tap(x, y);
});
const sndb = document.getElementById('sndb');
const syncSnd = () => sndb.classList.toggle('off', !!save.muted);
document.querySelectorAll('button[data-a]').forEach(btn => btn.addEventListener('pointerdown', e => {
  e.preventDefault(); audio();
  const a = btn.dataset.a;
  if (a === 'hint') hint();
  else if (a === 'reset') reset();
  else if (a === 'daily') { startLevel(1, true); sfx.click(); }
  else if (a === 'snd') { save.muted = !save.muted; persist(); syncSnd(); sfx.click(); }
}));
document.addEventListener('contextmenu', e => e.preventDefault());
const shell = document.getElementById('shell');
function fit() { shell.style.transform = `translate(-50%,-50%) scale(${Math.min(innerWidth / 360, innerHeight / 640)})`; }
addEventListener('resize', fit); fit(); syncSnd();
if (location.hash === '#debug') window.__cs = { get G() { return G; }, tap, blockerOf, startLevel, generate, params, get mode() { return mode; }, get cell() { return cell; }, get ox() { return ox; }, get oy() { return oy; }, save };
requestAnimationFrame(frame);
})();
