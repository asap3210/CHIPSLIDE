package com.chipslide.game;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.webkit.MimeTypeMap;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;


import java.io.IOException;
import java.io.InputStream;

/** Carga el juego HTML5 (assets/www) vía https://appassets.androidplatform.net */
public class MainActivity extends Activity {
    private WebView web;

    private static WebResourceResponse serve(android.content.res.AssetManager am, String path) {
        try {
            InputStream in = am.open("www/" + path);
            String ext = MimeTypeMap.getFileExtensionFromUrl(path).toLowerCase();
            String mime;
            switch (ext) {
                case "js": mime = "text/javascript"; break;
                case "html": mime = "text/html"; break;
                case "css": mime = "text/css"; break;
                case "json": case "model": mime = "application/json"; break;
                case "mp3": mime = "audio/mpeg"; break;
                case "ogg": mime = "audio/ogg"; break;
                case "ttf": mime = "font/ttf"; break;
                case "otf": mime = "font/otf"; break;
                default:
                    mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext);
                    if (mime == null) mime = "application/octet-stream";
            }
            return new WebResourceResponse(mime, mime.startsWith("text/") || mime.contains("json") ? "UTF-8" : null, in);
        } catch (IOException e) {
            return null;
        }
    }

    @SuppressLint({"SetJavaScriptEnabled", "ClickableViewAccessibility"})
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        web = new WebView(this);
        web.setBackgroundColor(Color.BLACK);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(false);

        final android.content.res.AssetManager am = getAssets();
        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                if ("appassets.androidplatform.net".equals(r.getUrl().getHost())) {
                    String p = r.getUrl().getPath();
                    if (p == null || p.equals("/")) p = "/index.html";
                    WebResourceResponse resp = serve(am, p.substring(1));
                    if (resp != null) return resp;
                }
                return super.shouldInterceptRequest(v, r);
            }
        });
        web.loadUrl("https://appassets.androidplatform.net/index.html");
    }

    private void immersive() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    @Override public void onWindowFocusChanged(boolean f) { super.onWindowFocusChanged(f); if (f) immersive(); }
    @Override protected void onPause() { super.onPause(); web.onPause(); }
    @Override protected void onResume() { super.onResume(); web.onResume(); }
    @Override protected void onDestroy() { web.destroy(); super.onDestroy(); }
    @Override public void onBackPressed() { if (web.canGoBack()) web.goBack(); else super.onBackPressed(); }
}
