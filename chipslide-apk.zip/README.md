# Chipslide
Juego puzzle original con estética LCD retro (HTML5 en WebView). Todo el código, gráficos y sonidos son propios.
- APK de prueba: Actions → "Build APK".
- Para Play Store: Actions → "Release AAB" (ver secrets en el archivo).
